# Row 1 colorway system

## Locked construction

- Geometry, anchors, module size and sequence are immutable.
- The canonical repeating sequence is `1–2–3–4–5`.
- Each colorway is generated from one continuous 1200 × 240 master strip and sliced only after recoloring.
- Cream (`#F2EBDA`) and ink (`#1A1A1A`) remain fixed.
- Terracotta, yellow, blue and green are reassigned as coordinated structural roles.

## Families

- **A · Original:** terracotta-led.
- **B · Green-led:** terracotta and green roles exchange.
- **C · Blue-led:** lead becomes blue; blue becomes green; green becomes terracotta.
- **D · Yellow-led:** lead becomes yellow; its diamond becomes blue; blue becomes terracotta.

## Compatibility

Use complete same-suffix sequences: `1a–2a–3a–4a–5a`, `1b–2b–3b–4b–5b`, and so on. The fifth module wraps back to the first module of the same family. Cross-family adjacency is not guaranteed unless the two boundary signatures are explicitly matched.

Every family folder contains the editable master strip, five individual SVG/PNG modules and a 4K full-screen proof.
